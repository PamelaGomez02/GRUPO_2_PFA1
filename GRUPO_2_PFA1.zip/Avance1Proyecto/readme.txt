Grupo 2
Integrantes:
Daniela Díaz Araya.
María José Guadamuz Blanco.
Natalia Campos Aguilar.
María Pamela Gómez Sequeira.

Usamos Java with Ant

Autenticación inicial mediante una clase de Login.
Ingreso de nuevos clientes con sus datos personales y tipo de trámite.
Visualización de la cola de cada caja.

Clases:
Login.
Gestiona la verificación del usuario para dar acceso al sistema.
Tiquete.
Representa la información de cada cliente en el sistema.
Nodo.
Estructura de un nodo en la cola, que incluye un Tiquete y una referencia al siguiente nodo.
Cola.
Representa cada caja de atención como una cola de clientes.
ControlCajas.
Gestiona todas las cajas (colas de clientes) del sistema.
Main.
Controla el flujo principal de ejecución del programa.